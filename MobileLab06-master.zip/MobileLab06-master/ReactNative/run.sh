export ANDROID_HOME=/Users/maksymdavydov/Library/Android/sdk/
react-native run-android

